
package flowerstore8;

import java.util.ArrayList;

public class MyThread extends Thread {

    private ArrayList<ArrayList<Integer>> matrix1;
    private ArrayList<ArrayList<Integer>> matrix2;
    private int n;
    private int number;
    private ArrayList<ArrayList<Integer>> result;

    public void setData(ArrayList<ArrayList<Integer>> matrix1, ArrayList<ArrayList<Integer>> matrix2, int n, int number){
        this.matrix1 = matrix1;
        this.matrix2 = matrix2;
        this.number = number;
        this.n = n;
        this.result = new ArrayList<ArrayList<Integer>>();
    }


    private void calculate() {
        int range = matrix1.size() / n;
        int start = number * range;
        int finish = start+range;
        if(number == n-1){
            finish = matrix1.size();
        }
        for (int  row = start; row < finish; row++) {
            ArrayList<Integer> vector = new ArrayList<>();
            for (int col = 0; col < matrix1.get(row).size(); col++) {
                int sum = 0;
                for(int num = 0; num < matrix1.get(row).size(); num++){
                    sum += matrix1.get(row).get(num)*matrix2.get(num).get(col);
                }
                vector.add(sum);
            }
            result.add(vector);
        }
    }

    ArrayList<ArrayList<Integer>> getResult(){
        return result;
    }

    @Override
    public void run() {
        calculate();
    }

}