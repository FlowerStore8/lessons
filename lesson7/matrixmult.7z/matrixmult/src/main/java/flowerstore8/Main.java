package flowerstore8;

import javax.swing.*;
import java.util.ArrayList;

/**
 * Hello world!
 *
 */
public class Main
{
    public static void main( String[] args )
    {
        ArrayList<ArrayList<Integer>> matrixA = new ArrayList<>();
        ArrayList<ArrayList<Integer>> matrixB = new ArrayList<>();
        for(int i = 0; i < 3; i++){
            ArrayList<Integer> vector1 = new ArrayList<>();
            ArrayList<Integer> vector2 = new ArrayList<>();
            for(int j = 0; j < 3; j++){
                vector1.add((int) (Math.random() * 10));
                vector2.add((int) (Math.random() * 10));
            }
            matrixA.add(vector1);
            matrixB.add(vector2);
        }

        for(ArrayList<Integer> string : matrixA){
            System.out.println(string);
        }

        System.out.println("");

        for(ArrayList<Integer> string : matrixB){
            System.out.println(string);
        }

        System.out.println("");

        ArrayList<ArrayList<Integer>> result = Bob.solution(matrixA, matrixB, 5);
        for(ArrayList<Integer> string : result){
            System.out.println(string);
        }
    }
}