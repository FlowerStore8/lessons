package flowerstore8;

import java.util.ArrayList;

class Bob {

    static ArrayList<ArrayList<Integer>> solution(ArrayList<ArrayList<Integer>> matrixA, ArrayList<ArrayList<Integer>> matrixB, int n){
        ArrayList<MyThread> threads = new ArrayList<>();
        for(int i = 0; i < n; i++){
            MyThread thread = new MyThread();
            thread.setData(matrixA, matrixB, n, i);
            threads.add(thread);
            thread.start();
        }
        for(MyThread thread : threads){
            try {
                thread.join();
            }
            catch (InterruptedException ex){
                ex.printStackTrace();
            }
        }
        ArrayList<ArrayList<Integer>> result = new ArrayList<>();
        for(MyThread thread : threads){
            result.addAll(thread.getResult());
        }
        return result;
    }
}
